# J&K Permanent Lighting — Website

Premium, mobile-first static website for **J&K Permanent Lighting** in Amarillo, Texas and surrounding areas.

## Files

- `index.html` — complete website structure and copy
- `styles.css` — visual design, responsive layout, animations
- `script.js` — mobile navigation, smooth scrolling, FAQ behavior, estimate-form handling

## Business information already built in

- J&K Permanent Lighting
- Amarillo, TX & surrounding areas
- Phone: 806-206-4615
- Email: keaganjhnsn@gmail.com
- Free estimates
- Residential and commercial
- 50% deposit after estimate/design approval to secure the project and order materials
- Remaining balance due upon completion
- No public pricing

## Photos / media

The site intentionally uses premium media slots instead of copying manufacturer website photos.

When approved manufacturer marketing images are obtained, or when J&K has its own project photos, replace the media-slot blocks in `index.html` with `<img>` elements. Manufacturer examples should remain clearly labeled:

> Manufacturer Example — Not a J&K Installation

Do not copy or host manufacturer website photography unless J&K has permission or approved dealer marketing assets.

## Estimate form setup

The form is prepared for Formspree but currently contains:

`https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID`

Create a Formspree form that sends to `keaganjhnsn@gmail.com`, then replace the placeholder URL in `index.html` with the real endpoint.

The form collects project type, stories, illuminated areas, measurements, approximate footage, lighting style, photos, name, phone, email, address, preferred contact method, and notes.

## GitHub Pages

1. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the root of the repository.
2. In GitHub, open **Settings → Pages**.
3. Choose **Deploy from a branch**.
4. Select your main branch and `/ (root)`.
5. Save and wait for GitHub Pages to publish.

## Before launch

- Connect the Formspree endpoint.
- Replace media slots with approved manufacturer photos or J&K-owned project photos.
- Add the final logo/brand asset if one is created.
- Test the estimate form and photo uploads on a phone.
- Test phone and SMS buttons on mobile.
